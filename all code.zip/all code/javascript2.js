var person={name:'seetha',
age:24,
height:157,
weight:60.5,
address:{house:23,
    street:3,
    location:'yelahanka'
}
}
person.age=26;
for (var i in person){
    console.log(person[i]);
}
console.log(person[i].location)