// Function to calculate CGPA
function calculateCGPA(subjectMarks) {
    var totalCredits = 0;
    var totalGradePoints = 0;
    // Define grade points for each grade
    var gradePoints = {
        'A+': 4.0, 'A': 4.0, 'A-': 3.7,'B+': 3.3,
        'B': 3.0, 'B-': 2.7, 'C+': 2.3,'C': 2.0,
        'C-': 1.7,'D+': 1.3,'D': 1.0, 'F': 0.0
    };
                    // Iterate over subject marks
    for (var subject in subjectMarks) {
        if (subjectMarks.hasOwnProperty(subject)) {
            var grade = subjectMarks[subject].grade;
            var credits = subjectMarks[subject].credits;
                    // Add credits to total credits
            totalCredits += credits;
                    // Add grade points to total grade points
            totalGradePoints += gradePoints[grade] * credits;
        }
    }
                // Calculate CGPA
    var cgpa = totalGradePoints / totalCredits;
    return cgpa.toFixed(2); // Round to 2 decimal places
}

var subjectMarks = {
    'Maths': { grade: 'A', credits: 3 },
    'Science': { grade: 'B+', credits: 4 },
    'English': { grade: 'A-', credits: 3 },
    'History': { grade: 'B', credits: 3 }
};

var cgpa = calculateCGPA(subjectMarks);
console.log("CGPA: " + cgpa);
