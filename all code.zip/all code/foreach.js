let text = "";
const fruits = ["apple", "orange", "cherry"];
fruits.forEach(myFunction);


function myFunction(item,index) {
    console.log(index,":",item);
}
