// Using array literal syntax
var fruits = ["apple", 'banana', 'orange',12,13.5];

// Using the Array constructor
var numbers = new Array(1, 2, 3, 4, 5,'abc');
for (i=0;i<numbers.length;i++){
    console.log(numbers[i]);
}
console.log(fruits); 
