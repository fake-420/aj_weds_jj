
// program to validate the phone number

function validatePhone(num) {

    // regex pattern for phone number
    const re = /^[9876]\d{9}/;

    // check if the phone number is valid
    let result = num.match(re);
    if (result) {
        console.log('The number is valid.');
    }
    else {
        let num = prompt('Enter number in 10 digit format:');
        validatePhone(num);
    }
}

// take input
let number = prompt('Enter number in 10 digit format:');

validatePhone(number);
function validateEmail(email) {
    // regex pattern for email
    const re = /\S+@\S+\.\S+/g;

    // check if the email is valid
    let result = re.test(email);
    if (result) {
        console.log('The email is valid.');
    }
    else {
        let newEmail = prompt('Enter a valid email:');
        validateEmail(newEmail);
    }
}
// take input
let email = prompt('Enter an email: ');

validateEmail(email);
